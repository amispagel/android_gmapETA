package edu.cpp.mispagel_project;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.MalformedInputException;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends Activity {

    String contactsautotextcsv = "";
    String contactsautotextarray[];
    String phonenumber = "";
    String str="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AutoCompleteTextView contactsautotext = (AutoCompleteTextView) findViewById(R.id.contactsautotext);//get values from user

        //Filter for cursor
        String selection = "(" + ContactsContract.Contacts.IN_VISIBLE_GROUP +
                " = '1' AND " + ContactsContract.Contacts.HAS_PHONE_NUMBER + " != 0 AND " +
                ContactsContract.CommonDataKinds.Phone.TYPE + " = " +
                ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE + ")"; //EXTRA CREDIT

        //Retrieve cursor using filter
        Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null,
                selection,
                null,
                ContactsContract.Contacts.DISPLAY_NAME + " ASC");

        //Read the cursor into a string
        while (phones.moveToNext()) {

            //Read Contact Name
            String name = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

            //Read Phone Number
            String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            phonenumber = phonenumber.replaceAll("[^0-9] ", "");
            if (name != null)
                contactsautotextcsv += phoneNumber + " > " + name + "!!!"; //separate with !!! for easy array creation with string.split("!!!")
        }
        phones.close();
        //Convert contactsautotextcsv into array
        contactsautotextarray = contactsautotextcsv.split("!!!");
        //Create Array Adapter and Pass ArrayOfValues to it
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1, contactsautotextarray);

        //BindAdapter with our Actual AutoCompleteTextView
        contactsautotext.setAdapter(adapter);
    }

    public void submitclicked(View view) {
        AutoCompleteTextView contactsautotext = (AutoCompleteTextView) findViewById(R.id.contactsautotext);//get values from user

        EditText delayminutestext = (EditText) findViewById(R.id.delayeditText);
        CheckBox sendnow = (CheckBox) findViewById(R.id.sendnowcheckBox);

        String selectedphonenumber = contactsautotext.getText().toString();
        long delayminutes = Long.parseLong(delayminutestext.getText().toString());

        //Trim phone number if it was selected from autocomplete
        if(selectedphonenumber.contains(">")) {
            //TRIM  contactsautotext entry to phone number
            selectedphonenumber = selectedphonenumber.substring
                    (0, selectedphonenumber.indexOf(">") - 1);
            phonenumber = selectedphonenumber.replaceAll("[^0-9.]", "");
        }else{phonenumber=selectedphonenumber;}

        //Schedule texts
        final Timer mytimer = new Timer(true);
        final String scheduletext = "I'm almost there! I'm a few minutes away.";
        final TimerTask mytask = new TimerTask() {
            public void run() {sendSMS(phonenumber, scheduletext);}
        };
        long delay = delayminutes * 60 * 1000;
        mytimer.schedule(mytask, delay);

        //send text now if checkbox is checked
        if(sendnow.isChecked())
        sendSMS(phonenumber, "I'm on my way, leaving now!");

        //String msg = "Please pick me up at " + when + " in " + where + ". Thank you. Alan";
        //Toast.makeText(getApplicationContext(), "Request Send", Toast.LENGTH_LONG).show();
        //sendSMS(phonenumber, msg);
    }

    public void calculatetraveltimeclicked(View view) {

        EditText from = (EditText) findViewById(R.id.fromeditText);
        EditText to = (EditText) findViewById(R.id.toeditText);
        String fromaddress = from.getText().toString();
        String toaddress = to.getText().toString();
        fromaddress.replaceAll("\\s", "+");
        toaddress.replaceAll("\\s", "+");
        String APIKEY = "AIzaSyBdFJjGAjIvBKr90SBVDcupGuAA9tvr0cg";
        String url ="https://maps.googleapis.com/maps/api/distancematrix/json?origins=";
        url+= fromaddress + "&destinations=" + toaddress + "&language=en-FR&key=" + APIKEY;
        new ReadJSONFeedTask().execute(url);
    }

    //Send an SMS message to another device
    private void sendSMS(String phoneNumber, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }

    private String downloadText(String param) {
        try{
            URL url = new URL(param);
            HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            if(con.getResponseCode() == HttpURLConnection.HTTP_OK) {
                BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                StringBuilder sr = new StringBuilder();
                String line = "";
                while ((line = br.readLine()) != null){
                    sr.append(line);
                }
                str=sr.toString();
            }
        } catch (MalformedInputException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }
        return str;
    }
    private class ReadJSONFeedTask extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... urls) {
            return downloadText(urls[0]);
        }

        protected void onPostExecute(String result) {
            try {
                JSONObject obj;
                obj = new JSONObject(result);
                String duration=obj.getJSONArray("rows").getJSONObject(0).getJSONArray("elements")
                        .getJSONObject(0).getJSONObject("duration").get("value").toString();
                int timeinseconds = Integer.parseInt(duration);
                Toast.makeText(getBaseContext(), "Travel time is: " + timeinseconds/60 + " minutes."
                        ,Toast.LENGTH_SHORT).show();
            }catch (JSONException e){
            e.printStackTrace();
            }
        }
    }

}
